
	import java.util.Map;
	import java.util.Set;

	import javax.swing.JTextField;
	
	
	public abstract class ActionBDD {
		protected String table;
		public ActionBDD(String table) {
			this.table = table;
		}
		public abstract String RequeteBuild(Map<String,JTextField> champs);
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}
		
	}


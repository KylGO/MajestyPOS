/**
 * Fenêtre du panel de gestion de la bdd
 * 
 * - Afficher les différentes tables de la BDD
 * - Ajouter , Modifier , Supprimer des lignes de la BDD
 * - Trier ( Croissant / Décroissant ) chaque colonnes de chaque table
 * 
 * 
 */


import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.swing.*;

public class ModifPanel extends JFrame{
	private String bdd = "majesty";
	private JTable table;
	private JPanel PanelDonne;
	private JPanel PanelAjout;
	private JPanel PanelTri;
	private String tableChoisi = "";

	private Map<String,JTextField> champs;
	private boolean tri_actif = false;
	
	
	public ModifPanel(String bdd) {
		this.bdd = bdd;
		connectionbd.setBdd(bdd);
		
		setTitle(bdd+".sql");
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setLayout(new BorderLayout(5,10));
		JLabel titre = new JLabel();
		titre.setText("Panel de modification de Majesty.SQL");
		titre.setFont(new Font("Serif",Font.BOLD,25));
		

		JPanel panelDonnee = new JPanel(new BorderLayout(10,15));
		panelDonnee.add(TablePanelHaut(),BorderLayout.NORTH);
		panelDonnee.add(TablePanelCentre(),BorderLayout.CENTER);
		add(titre,BorderLayout.NORTH);
		add(TablePanelGauche(),BorderLayout.WEST);
		add(panelDonnee,BorderLayout.CENTER);
		
		table.getSelectionModel().addListSelectionListener(e -> {
			int selectedRow = table.getSelectedRow();
			if(selectedRow==-1) {
				return;
			}
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			
			/*fillfield(model,selectedRow,champs);*/
		});
		setVisible(true);

		
				
	}
	
	/**
	 * Assemblage Swing de la table affiché , des boutons de tri , et d'ajout/modification/supprimer
	 * @return Base de données , boutons de tri , boutons d'ajout présent au centre du panel
	 */
	
	private JPanel TablePanelCentre() {
		JPanel donnee = new JPanel(new BorderLayout());
		donnee.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(156,156,158),4)));

		table = new JTable();
		JScrollPane scroll = new JScrollPane(table);
		PanelAjout = new JPanel();
		PanelTri = new JPanel();
		
		donnee.add(PanelAjout,BorderLayout.SOUTH);
		
		donnee.add(scroll,BorderLayout.CENTER);
		donnee.add(PanelTri,BorderLayout.EAST);
		return donnee;
	}
	
	/**
	 * Création et assemblages des différents boutons , Ajouter , Supprimer , Modifier dans un panel présent en haut de la page
	 * 
	 * @return Panel swing des Boutons 
	 */
	private JPanel TablePanelHaut() {
		JPanel options = new JPanel();
		options.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(156,156,158),4)));

		JButton ajout = new JButton();
		ajout.setBackground(new Color(151,206,81));

		ajout.setText("Ajouter");
		ajout.setFont(new Font("Serif",Font.BOLD,85));
		ajout.setMaximumSize(new Dimension(500,120));
		ajout.addActionListener(e -> ExecuteAction("ajout"));
		options.add(ajout,BorderLayout.NORTH);
		
		JButton modif = new JButton();
		modif.setBackground(new Color(242,245,118));
		modif.setText("Modifier");
		modif.setFont(new Font("Serif",Font.BOLD,85));
		modif.setMaximumSize(new Dimension(500,120));
		modif.addActionListener(e -> ExecuteAction("modif"));

		options.add(modif,BorderLayout.NORTH);
		
		JButton delete = new JButton();
		delete.setBackground(new Color(205,90,81));

		delete.setText("Supprimer");
		delete.setFont(new Font("Serif",Font.BOLD,85));
		delete.setMaximumSize(new Dimension(500,120));
		delete.addActionListener(e -> ExecuteAction("suppr"));

		options.add(delete,BorderLayout.NORTH);	
		
		return options;
	}
	
	
	/**
	 * Création du panel de boutons de différentes tables présent à droite de l'écran 
	 * 
	 *  - Detecte toutes les tables présentes dans la bdd donné
	 *  - Créer des boutons pour chacun
	 *  - Créer un bouton pour afficher les valeurs de la table
	 *  
	 *  - Bouton Retour pour revenir à la page de gestion du Restaurant
	 * @return Le panel swing scrollabe des boutons des tables présente
	 */
	
	private JScrollPane TablePanelGauche() {
	

		JPanel tables_panel = new JPanel();
		tables_panel.setLayout(new BoxLayout(tables_panel,BoxLayout.Y_AXIS));
		JScrollPane tables = new JScrollPane(tables_panel);

		DefaultTableModel model = new DefaultTableModel();
		model = generalDAO.getTable("SHOW tables FROM "+bdd);
		for(int i =0;i<model.getRowCount();i++) {
			String nom_table = model.getValueAt(i, 0).toString();
			JButton btn_tab = new JButton();
			btn_tab.setBackground(new Color(105,105,105));
			btn_tab.setForeground(Color.WHITE);
			btn_tab.setText(nom_table);
			btn_tab.setFont(new Font("Serif",Font.BOLD,85));
			btn_tab.setMaximumSize(new Dimension(500,120));
			btn_tab.addActionListener(e -> afficherBDD("SELECT * FROM "+nom_table,nom_table));
			tables_panel.add(Box.createVerticalStrut(25));
			
			
			tables_panel.add(btn_tab);	
			
		}
		JButton btn_sortir = new JButton();
		btn_sortir.setBackground(new Color(45,0,0));
		btn_sortir.setForeground(Color.WHITE);
		btn_sortir.setText("Retour");
		btn_sortir.setFont(new Font("Serif",Font.BOLD,45));
		btn_sortir.setMaximumSize(new Dimension(500,120));
		btn_sortir.addActionListener(e -> 
		dispose()
		
				);
		tables_panel.add(Box.createVerticalStrut(25));

		tables_panel.add(btn_sortir);	

		tables_panel.add(Box.createVerticalStrut(25));
		tables_panel.add(Box.createHorizontalStrut(50));

		return tables;
	}
	
	
	/**
	 * Execute l'action passé en paramètre : "ajout" , "modif" , "suppr"
	 * 
	 * - Créer les JTextField en fonction de l'action
	 * - Créer un bouton qui créer la requête correspondante en appelant la classe ActionBDD
	 * - Execute la requête avec l'api et affiche la nouvelle table
	 * @param Action "ajout" / "modif" / "suppr"
	 */
	
	private void ExecuteAction(String Action) {
		PanelAjout.removeAll();
		if(tableChoisi!="") {
		
			JButton submitCart2 = new JButton();
			JPanel Ajoutpanel = new JPanel();
			DefaultTableModel model = new DefaultTableModel();
			model = generalDAO.getTable("SELECT * FROM "+tableChoisi); // Avoir un modèle sur lequel se basé pour construire les JTextField
			Map<String, JTextField> champs = new LinkedHashMap<>(); // LinkedHashMap pour l'ordre [IdCarte , nom , description]
	
			if(Action=="ajout") {
				for(int i = 1;i<model.getColumnCount();i++) {
					System.out.println(model.getColumnName(i)+" < Label JTEXTFIELD");
					System.out.println(model.getColumnCount()+" < Nbr de JTEXTFIELD");
					
					JTextField nv_textfield = new JTextField(); // Construction des JTextField
					nv_textfield.setPreferredSize(new Dimension(150,30));
					PanelAjout.add(new JLabel(model.getColumnName(i)));
					PanelAjout.add(nv_textfield);
					champs.put(model.getColumnName(i),nv_textfield);
				}
	
				
				submitCart2.setText("Ajouter");
				submitCart2.setBackground(new Color(151,206,81));
				submitCart2.addActionListener(e -> {
					System.out.println("PARTIE AJOUT");
					ActionBDD action = new Ajout(tableChoisi);
					String requete = action.RequeteBuild(champs);
					generalDAO.RequeteTable(requete);
					afficherBDD("SELECT * FROM "+ tableChoisi, tableChoisi);
				});
				
			}
			if(Action=="modif") {
				PanelAjout.add(new JLabel("Choisir L'ID ->  "));
	
				for(int i = 0;i<model.getColumnCount();i++) {
					System.out.println(model.getColumnName(i));
					System.out.println(model.getColumnCount());
					
					JTextField nv_textfield = new JTextField();// Construction des JTextField
					nv_textfield.setPreferredSize(new Dimension(150,30));
					PanelAjout.add(new JLabel(model.getColumnName(i)));
					PanelAjout.add(nv_textfield);
					champs.put(model.getColumnName(i),nv_textfield);
					if(i==0) {
						PanelAjout.add(Box.createHorizontalStrut(15));
					}
				}
				System.out.println(champs.keySet());
	
				submitCart2 = new JButton("Modifier");
				submitCart2.setBackground(new Color(242,245,118));
				submitCart2.addActionListener(e -> {	
					System.out.println("PARTIE MODIF");
	
					ActionBDD action = new Modif(tableChoisi);
					String requete = action.RequeteBuild(champs);
					generalDAO.RequeteTable(requete);
					afficherBDD("SELECT * FROM "+ tableChoisi, tableChoisi);
				});
			}
			if(Action=="suppr") {
	
				for(int i = 0;i<1;i++) {
					System.out.println(model.getColumnName(i));
					System.out.println(model.getColumnCount());
					
					JTextField nv_textfield = new JTextField();// Construction des JTextField
					nv_textfield.setPreferredSize(new Dimension(150,30));
					PanelAjout.add(new JLabel(model.getColumnName(i)));
					PanelAjout.add(nv_textfield);
					champs.put(model.getColumnName(i),nv_textfield);
				}
				System.out.println(champs.keySet());
	
				submitCart2 = new JButton("Supprimer");
				submitCart2.setBackground(new Color(205,90,81));	
	
				submitCart2.addActionListener(e -> {	
					System.out.println("PARTIE SUPPR");
	
					ActionBDD action = new Suppr(tableChoisi);
					String requete = action.RequeteBuild(champs);
					generalDAO.RequeteTable(requete);
					afficherBDD("SELECT * FROM "+ tableChoisi, tableChoisi);
						
				});				
			

		}
			
		
		
		PanelAjout.add(submitCart2);
		PanelAjout.revalidate(); // Recalcule la position des composants Swing
		PanelAjout.repaint(); // Redessine les composants Swing
		}		
	}
	

	/*
	private void fillfield(DefaultTableModel model, int row, Map<String,JTextField> champs) {
		for(int i = 0;i<model.getColumnCount();i++) {
			String colName = model.getColumnName(i);
			String value = model.getValueAt(row, i).toString();
			champs.get(colName).setText(value);
		}
		switch(tableChoisi) {
		case "carte":
			if(nomCart!=null) {
				
			
			nomCart.setText(model.getValueAt(row,1).toString());
			descriptionCart.setText(model.getValueAt(row,2).toString());
			if(idCarte != null) {
				idCarte.setText(model.getValueAt(row,0).toString());

			}
			}
		break;
		case "categorie":
			if(nomCate!=null) {
				nomCate.setText(model.getValueAt(row,1).toString());
				descriptionCate.setText(model.getValueAt(row,2).toString());
				idCarteCate.setText(model.getValueAt(row,3).toString());
				if(idCategorie != null) {
					idCategorie.setText(model.getValueAt(row,0).toString());
					
				}
			}
		break;
		case "item":
			if(nomItem!=null) {
				nomItem.setText(model.getValueAt(row,1).toString());
				prixItem.setText(model.getValueAt(row,3).toString());				
				
				descriptionItem.setText(model.getValueAt(row,2).toString());
				idCategorieItem.setText(model.getValueAt(row,3).toString());	
				if(idItem != null) {
					idItem.setText(model.getValueAt(row,0).toString());
					
				}
			}
		break;
		}	
	}
	

	
	
	
	/**
	 * Affiche la base de données en Swing 
	 * 
	 * - Prend en paramètre la requête et le nom de la table choisi
	 * - Passe la requête à l'API
	 * @param query
	 * @param nom_table
	 */
	private void afficherBDD(String query,String nom_table) {
		PanelAjout.removeAll();
		PanelAjout.revalidate();
		PanelTri.removeAll();
		PanelTri.setLayout(new BoxLayout(PanelTri,BoxLayout.Y_AXIS));
		DefaultTableModel model = new DefaultTableModel();
		model = generalDAO.getTable(query);
		for(int i = 0; i<model.getColumnCount();i++) {
			final int colIndex = i;
			String nom_col = model.getColumnName(i);
			JButton nv_btn_tri = new JButton();
			nv_btn_tri.setBackground(new Color(105,105,105));
			nv_btn_tri.setForeground(Color.WHITE);
			nv_btn_tri.setText("Trier par "+nom_col);
			nv_btn_tri.setFont(new Font("Serif",Font.BOLD,15));
			nv_btn_tri.setMaximumSize(new Dimension(500,120));
			nv_btn_tri.addActionListener(e -> { /* Lambda + API STREAM */
				if(tri_actif==false) {
					afficherBDD("SELECT * FROM "+nom_table+" ORDER BY "+nom_col,nom_table);


					tri_actif = true;
				} else {
					afficherBDD("SELECT * FROM "+nom_table+" ORDER BY "+nom_col+" DESC",nom_table);
					tri_actif = false;
					
					
				}
			});
			PanelTri.add(nv_btn_tri);
		}

		
		
		PanelTri.revalidate();
		PanelTri.repaint();
		table.setModel(model);
		tableChoisi = nom_table;			
		
	
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ModifPanel("majesty");
	}

}
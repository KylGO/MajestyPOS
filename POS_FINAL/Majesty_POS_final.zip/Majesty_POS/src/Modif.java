import java.util.Map;
import java.util.Set;

import javax.swing.JTextField;

/**
		 * Construit une requete de modification dans la base de données
		 * @return requete string UPDATE
		 */
		class Modif extends ActionBDD{
			public Modif(String table) { super(table); }

			public String RequeteBuild(Map<String,JTextField> champs) {
				String update_requete = "";
				String update_condition = "";
				int i = 0;
				Set<String> tab_set = champs.keySet();		
				for(String item : tab_set) {
					System.out.println(champs.get(item).getText());
					System.out.println(item.toString()+"AAAAA");	
					System.out.println(i);
					i = i+1;
					System.out.println(i+" TEST");
					if(i==1) {
						update_condition = item.toString()+"='"+champs.get(item).getText()+"'";
					}
					if(i==2) {
						
						update_requete = item.toString()+"='"+champs.get(item).getText()+"'";

					} else {
						update_requete = update_requete+", "+item.toString()+"='"+champs.get(item).getText()+"'";
						
					}
				}
					String requete = "UPDATE "+this.table+" SET "+update_requete+" WHERE "+update_condition;
					System.out.println(requete+"REQ");
					System.out.println("Ajout BON");

				
				return requete;
			}
		}
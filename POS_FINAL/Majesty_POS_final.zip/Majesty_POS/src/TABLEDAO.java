import java.sql.*;

public class TABLEDAO {
	
	public static void RequeteTableCarte(String requete) {
	    try (Connection cn = ConnectionBDD.getConnection();
	         Statement stmt = cn.createStatement()) {

	        stmt.executeUpdate(requete);

	    } catch(SQLException e) {
	        e.printStackTrace();
	    }
	}
  
	public static boolean CommandeActive(int numero) {
	    String sql = "SELECT COUNT(*) FROM commande WHERE numTable = ? AND actif = 1";

	    try (Connection connection = ConnectionBDD.getConnection();
	         PreparedStatement ps = connection.prepareStatement(sql)){

	        ps.setInt(1, numero);
	        ResultSet rs = ps.executeQuery();
	        rs.next();
	        return rs.getInt(1) > 0;

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	
	public static String getCommandePourTable(int numero) {
		
	    StringBuilder resultat = new StringBuilder();

	    String sql =
	        "SELECT i.nom, ci.quantite, ci.prixItemUnite, " +
	        "(ci.quantite * ci.prixItemUnite) AS totalItem " +
	        "FROM commande c " +
	        "JOIN commandeitem ci ON c.idCommande = ci.idCommande " +
	        "JOIN item i ON ci.idItem = i.idItem " +
	        "WHERE c.numTable = ? AND c.actif = 1";


	    try (Connection connection = ConnectionBDD.getConnection();
	         PreparedStatement ps = connection.prepareStatement(sql)) {
		    ps.setInt(1, numero);

	        try (ResultSet rs = ps.executeQuery()) {

	            if (!rs.next()) {
	                return "Aucune commande active pour cette table.";
	            }

	            do {
	                resultat.append(rs.getInt("quantite"))
	                        .append("x ")
	                		.append(rs.getString("nom"))
	                        .append(" * ")
	                        .append(rs.getDouble("prixItemUnite"))
	                        .append(" € = ")
	                        .append(rs.getDouble("totalItem"))
	                        .append(" €\n");

	            } while (rs.next());
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return "Erreur lors du chargement de la commande";
	    }
	    return resultat.toString();
   
	}
}

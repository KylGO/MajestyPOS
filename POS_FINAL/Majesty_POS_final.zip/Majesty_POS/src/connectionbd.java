import java.sql.*;

public class connectionbd {
	 private static Connection cn;
	    private static String Bdd;
	    private connectionbd() {
	        try {
	            String url="jdbc:mysql://localhost:3306/"+Bdd;
	            String user="root";
	            String password="";
	            cn = DriverManager.getConnection(url,user,password);
	            System.out.println("OK");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public static Connection getConnection() throws SQLException{
	        if(cn == null) {
	            System.out.println("Cn NULL");
	            new ConnectionBDD();
	        }
	        return cn;
	    }

	    public static void setBdd(String bdd) {
	        Bdd = bdd;
	    }



}

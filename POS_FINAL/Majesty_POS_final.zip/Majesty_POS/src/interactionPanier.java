

import java.util.HashMap;


public class interactionPanier {
	
	/**
	 * Permet d'interagir avec le Panier comme gérer le nombre d'item
	 */
	private HashMap<Integer, Integer> panier = new HashMap<>(); // clé : idItem || valeur : quantité
	
	public void ajouterItem(int key, int nbr) {
		if (panier.containsKey(key)) { // si item existant
			panier.put(key, nbr+panier.get(key)); // on remplace la clé précédente avec la nouvelle valeur+l'ancienne
		}else {
			panier.put(key, nbr); // sinon on crée une nouvelle paire
		}
	}
	
	public void supprimerItem(int key) {
		/**
		 * On supprime un item et si item = 0, on supprime la clé
		 */
		if(panier.containsKey(key)) {
			int nbrItemMoinsUn = nbrItem(key) - 1;
			if(nbrItemMoinsUn <= 0) {
				panier.remove(key);
			}else {
				panier.put(key, nbrItemMoinsUn); // on remplace la clé précédente avec l'ancienne valeur-1				
			}
		}
	}
	
	public int nbrItem(int key) {
		return panier.get(key);
	}
	
	public void afficherPanier() {
		for (int i : panier.keySet()) {
			System.out.println("key: " + i + " value: " + panier.get(i));
		}
	}
	
	public int taillePanier() {
		return panier.size();
	}

	public HashMap<Integer, Integer> getPanier() {
		return panier;
	}
	
	
	/*// test de la class
	public static void main(String[] args) {
		interactionPanier panier1 = new interactionPanier();
		panier1.ajouterItem("CTT",1);
		panier1.afficherPanier();
		System.out.println("-------------------------");
		panier1.ajouterItem("CTT",12);
		panier1.afficherPanier();
		System.out.println("-------------------------");
		panier1.supprimerItem("CTT");
		panier1.afficherPanier();
		System.out.println("-------------------------");
		panier1.ajouterItem("Sabzi", 1);
		panier1.afficherPanier();
		System.out.println("-------------------------");
		panier1.supprimerItem("Sabzi");
		panier1.afficherPanier();
		System.out.println("-------------------------");
		panier1.supprimerItem("jsp");
		panier1.afficherPanier();
		System.out.println("-------------------------");
	}
	*/
}


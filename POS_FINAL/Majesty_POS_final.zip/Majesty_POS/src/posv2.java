

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;
 
public class posv2 extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;
    private Map<String, String> etatTables = new HashMap<>();

   
   
    
 
    
    private BDDrequetes bdd;

    public posv2() {
    	
    	bdd = new BDDrequetes();
    	bdd.connectionBDD();
    	
        setTitle("POS " + bdd.getNomRestaurant() );
        setSize(900, 600);
        setBackground(new Color(120, 161, 187));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setLayout(new BorderLayout());
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                int confirm = JOptionPane.showConfirmDialog(
                        posv2.this,
                        "Voulez-vous vraiment fermer l'application ?",
                        "Confirmation",
                        JOptionPane.YES_NO_OPTION
                );

                if (confirm == JOptionPane.YES_OPTION) {

                    // SUPPRESSION DE TOUTES LES TABLES
                    TABLEDAO.RequeteTableCarte("DELETE FROM tableclient");
                    dispose();
                }
            }
        });
        
        

 
        // -----------------------------
        // PANEL LATERAL GAUCHE (menu)
        // -----------------------------
        JPanel sideMenu = new JPanel();
        sideMenu.setLayout(new GridLayout(5, 1, 5, 5));
        sideMenu.setPreferredSize(new Dimension(200, 0));
        sideMenu.setBackground(new Color(235, 245, 238));;

        JButton btnAccueil = new JButton("Accueil");
        JButton btnTables = new JButton("Tables");
        JButton btnCarte = new JButton("Commandes");
        JButton btnReglages = new JButton("Reglages");

        sideMenu.add(btnAccueil);
        sideMenu.add(btnTables);
        sideMenu.add(btnCarte);
        sideMenu.add(btnReglages);

        add(sideMenu, BorderLayout.WEST);

        // -----------------------------
        // CARDLAYOUT (zone principale)
        // -----------------------------
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createAccueilPanel(), "Accueil");
        mainPanel.add(createCartePanel(), "Commandes");
        mainPanel.add(createTablesPanel(), "Tables");
        mainPanel.add(createRegalgesPanel(), "Reglages"); 
        add(mainPanel, BorderLayout.CENTER);

        // -----------------------------
        // Boutons Principaux
        // -----------------------------
        btnAccueil.addActionListener(e -> cardLayout.show(mainPanel, "Accueil"));
        btnCarte.addActionListener(e -> cardLayout.show(mainPanel, "Carte"));
        btnCarte.addActionListener(e -> cardLayout.show(mainPanel, "Commandes"));
        btnTables.addActionListener(e -> cardLayout.show(mainPanel, "Tables"));
        btnReglages.addActionListener(e -> cardLayout.show(mainPanel, "Reglages"));

 
    }

    // -----------------------------
    // PANNEAU : ACCUEIL
    // -----------------------------
    private JPanel createAccueilPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Bienvenue dans Majesty POS", SwingConstants.CENTER);
        JButton modif = new JButton ("Modifier Infos du Restaurant");

        modif.addActionListener(x -> {
              // créer le popup
            RestaurantInfo dialog = new RestaurantInfo(this); // 'this' = posv2 actuel

            // pré rempli les endroits de texte avec les infos de la bdd
            dialog.setNom(bdd.getNomRestaurant());
            dialog.setAdresse(bdd.getAdresseRestaurant());
            dialog.setTelephone(bdd.getNumeroRestaurant());
            dialog.setVisible(true);

            bdd.mettreAJourInfosRestaurant(
                dialog.getNomRestaurant(),
                dialog.getAdresseRestaurant(),
                dialog.getTelephoneRestaurant()
            );

            System.out.println("Restaurant mis  jour : " +
                               dialog.getNomRestaurant() + " / " +
                               dialog.getAdresseRestaurant() + " / " +
                               dialog.getTelephoneRestaurant());


        });




        panel.add(modif, BorderLayout.SOUTH);
        label.setFont(new Font("Arial", Font.BOLD, 26));
        panel.add(label, BorderLayout.CENTER);
        panel.setBackground(new Color(235, 245, 238));




        return panel;
    }

    // ------------------
    // PANNEAU : TABLES 
    // ------------------
    private void ajouterTable(JPanel panel, int num) {

        String tableName = "Table " + num;

        TABLEDAO.RequeteTableCarte(
            "INSERT INTO tableclient (numTable, etatTable) VALUES (" + num + ",0)"
        );

        JButton tableButton = new JButton(tableName);
        tableButton.setFont(new Font("Arial", Font.BOLD, 20));
        tableButton.setBackground(Color.GREEN);
        tableButton.setFocusPainted(false);

        tableButton.addActionListener(ev -> {

            JFrame fenetre2 = new JFrame("Option " + tableName);
            fenetre2.getContentPane().setBackground(new Color(235, 245, 238));
            fenetre2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            fenetre2.setSize(1100, 700);
            fenetre2.setLayout(new BorderLayout(15, 15));
            
            
            JPanel panelCommandes = new JPanel(new BorderLayout());
            panelCommandes.setPreferredSize(new Dimension(400, 600));

            JTextArea commandesTables = new JTextArea();
            commandesTables.setEditable(false);
            commandesTables.setFont(new Font("Arial", Font.PLAIN, 14));
            panelCommandes.add(new JScrollPane(commandesTables), BorderLayout.CENTER);

            if (!TABLEDAO.CommandeActive(num)) {
                commandesTables.setText("Aucune commande");
            } else {
                commandesTables.setText(TABLEDAO.getCommandePourTable(num));
            }

            JPanel panelCentre = new JPanel(new GridLayout(4, 5, 20, 20));
            panelCentre.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

            JButton btnLibre = new JButton("Fin de commande");
            JButton btnOccupe = new JButton("Occupé");
            JButton btnReserve = new JButton("Réservé");
            JButton btnimprimercommande = new JButton("Imprimer la commande de la " + tableName);
            Dimension btnSize = new Dimension(150, 30);

            for(JButton btn : new JButton[]{btnLibre, btnReserve, btnOccupe}) {
                btn.setPreferredSize(btnSize);
            }
            
            btnLibre.addActionListener(x -> {
                tableButton.setBackground(Color.GREEN);
                TABLEDAO.RequeteTableCarte(
                    "UPDATE tableclient SET etatTable = 0 WHERE numTable = " + num);
                
                TABLEDAO.RequeteTableCarte("UPDATE commande SET actif = 0 WHERE numTable = " + num);
                fenetre2.dispose();
            });

            btnOccupe.addActionListener(x -> {
                tableButton.setBackground(Color.YELLOW);
                TABLEDAO.RequeteTableCarte(
                    "UPDATE tableclient SET etatTable = 1 WHERE numTable = " + num
                );
                fenetre2.dispose();
            });

            btnReserve.addActionListener(x -> {
                tableButton.setBackground(Color.RED);
                TABLEDAO.RequeteTableCarte(
                    "UPDATE tableclient SET etatTable = 2 WHERE numTable = " + num
                );
                fenetre2.dispose();
            });
            btnimprimercommande.addActionListener(x -> {
            	String ticketText = TicketPrinter.generateTicketCaisseText(bdd, num);

            TicketPrinter.printTicket(ticketText);

            	
            });
            
            panelCentre.add(btnimprimercommande);
            panelCentre.add(btnOccupe);
            panelCentre.add(btnReserve);
            panelCentre.add(btnLibre);

            fenetre2.add(panelCommandes, BorderLayout.WEST);
            fenetre2.add(panelCentre, BorderLayout.EAST);
            fenetre2.setLocationRelativeTo(null);
            fenetre2.setVisible(true);
        });

        panel.add(tableButton); }
        
    private int nbTables = 10;

    private JPanel createTablesPanel() {

        JPanel panel = new JPanel(new GridLayout(4, 5, 20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        panel.setBackground(new Color(235, 245, 238));

        JButton plustable = new JButton("Ajouter une table");
        panel.add(plustable);
        
        JButton minustable = new JButton("Enlever une table");
        panel.add(minustable); 
        

        plustable.addActionListener(e -> {

            nbTables++;
            int num = nbTables;
            String tableName = "Table " + num;

            // INSERT BDD
            TABLEDAO.RequeteTableCarte(
            	"INSERT INTO tableclient (numTable, etatTable) VALUES (" + num + ",0)"
            );

            JButton tableButton = new JButton(tableName);
            tableButton.setFont(new Font("Arial", Font.BOLD, 20));
            tableButton.setBackground(Color.GREEN);
            tableButton.setFocusPainted(false);

            // =========================
            // CLIC SUR LA TABLE
            // =========================
            tableButton.addActionListener(ev -> {

                JFrame fenetre2 = new JFrame("Option " + tableName);
                fenetre2.getContentPane().setBackground(new Color(235, 245, 238));
                fenetre2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                fenetre2.setSize(1100, 700);
                fenetre2.setLayout(new BorderLayout(15, 15));

                JPanel panelCommandes = new JPanel(new BorderLayout());
                panelCommandes.setPreferredSize(new Dimension(400, 600));

                JTextArea commandesTables = new JTextArea();
                commandesTables.setEditable(false);
                commandesTables.setFont(new Font("Arial", Font.PLAIN, 14));
                panelCommandes.add(new JScrollPane(commandesTables), BorderLayout.CENTER);

                if (!TABLEDAO.CommandeActive(num)) {
                    commandesTables.setText("Aucune commande");
                } else {
                    commandesTables.setText(TABLEDAO.getCommandePourTable(num));
                }

                JPanel panelCentre = new JPanel(new GridLayout(4, 1, 20, 20));
                panelCentre.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20));
                panelCentre.setBackground(new Color(235, 245, 238));

                JButton btnLibre = new JButton("Fin de commande");
                JButton btnOccupe = new JButton("Occupé");
                JButton btnReserve = new JButton("Réservé");
                JButton btnimprimercommande = new JButton("Imprimer la commande de la " + tableName);
                Dimension btnSize = new Dimension(150, 30);

                for(JButton btn : new JButton[]{btnLibre, btnReserve, btnOccupe}) {
                    btn.setPreferredSize(btnSize);
                }

                //Fin de table z
                btnLibre.addActionListener(x -> {
                    tableButton.setBackground(Color.GREEN);
                    TABLEDAO.RequeteTableCarte(
                        "UPDATE tableclient SET etatTable = 0 WHERE numTable = " + num);
                    TABLEDAO.RequeteTableCarte("UPDATE commande SET actif = 0 WHERE numTable = " + num);
                    fenetre2.dispose();
                });

                btnOccupe.addActionListener(x -> {
                    tableButton.setBackground(Color.YELLOW);
                    TABLEDAO.RequeteTableCarte(
                        "UPDATE tableclient SET etatTable = 1 WHERE numTable = " + num
                    );
                    fenetre2.dispose();
                });

                btnReserve.addActionListener(x -> {
                    tableButton.setBackground(Color.RED);
                    TABLEDAO.RequeteTableCarte(
                        "UPDATE tableclient SET etatTable = 2 WHERE numTable = " + num
                    );

                    fenetre2.dispose();
                });
                
                
                btnimprimercommande.addActionListener(x -> {
                	String ticketText = TicketPrinter.generateTicketCaisseText(bdd, num);

                    TicketPrinter.printTicket(ticketText);
                });
                
                panelCentre.add(btnimprimercommande);
                panelCentre.add(btnOccupe);
                panelCentre.add(btnReserve);
                panelCentre.add(btnLibre);

                fenetre2.add(panelCommandes, BorderLayout.WEST);
                fenetre2.add(panelCentre, BorderLayout.EAST);
                fenetre2.setLocationRelativeTo(null);
                fenetre2.setVisible(true);
            });
            
        
            panel.add(tableButton);
            panel.revalidate();
            panel.repaint();
        });
        
      
        
        minustable.addActionListener(ev -> {
        	 // Sécurité : aucune table a supprimer
            if (nbTables <= 0) {
                JOptionPane.showMessageDialog(panel, "Aucune table a supprimer");
                return;
            }

            // Suppression en BDD (dernière table)
            TABLEDAO.RequeteTableCarte(
                "DELETE FROM tableclient WHERE numTable = " + nbTables
            );

            // Suppression du bouton de la fenétre
            // (dernier composant ajouté = dernière table)
            Component lastComponent = panel.getComponent(panel.getComponentCount() - 1);
            panel.remove(lastComponent);

            //  Décrément du compteur
            nbTables--;

            //  Rafraichissement UI
            panel.revalidate();
            panel.repaint();
        	
        });
        
        for (int i = 1; i <= nbTables; i++) {
            ajouterTable(panel, i);
        }
        

        return panel;
    }

    // -----------------------------
    // PANNEAU : COMMANDE
    // -----------------------------
    private JPanel createCartePanel() {
    	JPanel panel = new JPanel(new BorderLayout());

        JButton btncommande = new JButton("Ajouter une commande");
        btncommande.setPreferredSize(new Dimension(150, 30));
        

        btncommande.addActionListener(e -> {
            new  commande(); // appel de ta classe
        });
        panel.add(btncommande, BorderLayout.CENTER);

        return panel;
    }



    
    // -----------------------------
    // PANNEAU : Reglages
    // -----------------------------
    
    private JPanel createRegalgesPanel() {

    	JPanel panel = new JPanel(new BorderLayout());

        JButton btnModif = new JButton("Modifier la BDD");
        btnModif.setPreferredSize(new Dimension(150, 30));
        

        btnModif.addActionListener(e -> {
            new ModifPanel("majesty"); // appel de ta classe
        });

        panel.add(btnModif, BorderLayout.CENTER);
    	
    	
    return panel;	
    }
    
    
    
    
    ActionListener modifierRestaurantListener = e -> {

        // créer le popup
        RestaurantInfo dialog = new RestaurantInfo(this); // 'this' = posv2 actuel

        // pré rempli les endroits de texte avec les infos de la bdd
        dialog.setNom(bdd.getNomRestaurant());
        dialog.setAdresse(bdd.getAdresseRestaurant());
        dialog.setTelephone(bdd.getNumeroRestaurant());
        dialog.setVisible(true);

        bdd.mettreAJourInfosRestaurant(
            dialog.getNomRestaurant(),
            dialog.getAdresseRestaurant(),
            dialog.getTelephoneRestaurant()
        );

        System.out.println("Restaurant mis a jour : " +
                           dialog.getNomRestaurant() + " / " +
                           dialog.getAdresseRestaurant() + " / " +
                           dialog.getTelephoneRestaurant());
    };
    
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            posv2 app = new posv2(); 

            BDDrequetes bdd = new BDDrequetes();
            bdd.connectionBDD();
            
            // vérifier si le popup est nécessaire
            boolean popupOpen = (bdd.getNomRestaurant() == null || bdd.getNomRestaurant().isEmpty());

            if (popupOpen) {
                // popup seulement si la table est vide
                RestaurantInfo dialog = new RestaurantInfo(app);
                dialog.setVisible(true);

                bdd.sauvegarderInfosRestaurant(
                    dialog.getNomRestaurant(),
                    dialog.getAdresseRestaurant(),
                    dialog.getTelephoneRestaurant()
                );
            } else {
                System.out.println("Infos restaurant déja en base : " +
                                   bdd.getNomRestaurant() + " / " +
                                   bdd.getAdresseRestaurant() + " / " +
                                   bdd.getNumeroRestaurant());
            }

            // affichage de la partie de reyane
            app.setVisible(true);
        });
    }

 

}

import java.util.Map;
import java.util.Set;

import javax.swing.JTextField;

/**
		 * Construit une requete d'ajout dans la base de données
		 * @return requete string INSERT INTO
		 */

		class Ajout extends ActionBDD{
			public Ajout(String table) { 
				super(table); 
			}
			@Override
			public String RequeteBuild(Map<String,JTextField> champs) {
				String colonnes = "";
				String valeurs = "";
				int i = 0;
				Set<String> tab_set = champs.keySet();		
				for(String item : tab_set) {
					System.out.println(champs.get(item).getText());
					System.out.println(item.toString()+"AAAAA");	
					System.out.println(i);
					i = i+1;
					if(i==1) {
						colonnes = item.toString();
						valeurs = champs.get(item).getText();
					} else {
						colonnes = colonnes+","+item.toString();
						valeurs = valeurs+"','"+champs.get(item).getText();

					}
					System.out.println(valeurs+"TAAAA");
				}
					String requete = "INSERT INTO "+this.table+"("+colonnes+") VALUES('"+valeurs+"')";
					System.out.println(requete);
					System.out.println("Ajout BON");

				
				return requete;

			}
		}
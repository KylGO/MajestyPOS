import java.util.Map;
import java.util.Set;

import javax.swing.JTextField;

/**
		 * Construit une requete pour supprimer une ligne dans la base de données
		 * @return requete string DELETE
		 */
		class Suppr extends ActionBDD{
			public Suppr(String table) { super(table); }

			public String RequeteBuild(Map<String,JTextField> champs) {
				String update_condition = "";
				int i = 0;
				Set<String> tab_set = champs.keySet();		
				for(String item : tab_set) {
					System.out.println(champs.get(item).getText());
					System.out.println(item.toString()+"AAAAA");	
					System.out.println(i);
					i = i+1;
					if(i==1) {
						update_condition = item.toString()+"="+champs.get(item).getText();

					}
				}
					String requete = "DELETE FROM "+this.table+" WHERE "+update_condition;
					System.out.println(requete);
					System.out.println("Ajout BON");
				return requete;

			}	
		}


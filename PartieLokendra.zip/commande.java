package UI_POS;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

public class commande extends JFrame {
	
	/**
	 * Affichage de la fênetre de prise de commande
	 */
	private static final long serialVersionUID = 1L;

	private interactionPanier panier = new interactionPanier(); // on crée un panier vide
	
	private JTextField saisieNbrClient; // initialise textfield vide
	private JTextField saisieNumTable; // initialise textfield vide
	
	private JPanel panelCarte; // initialise panel vide
	private JPanel panelCategorie; // initialise panel vide
	private JPanel panelPlat; // initialise panel vide
	private JPanel panelPanier; // initialise panel vide
	
	private JLabel titreInfo = new JLabel(); // initialise label vide
	private JLabel descriptionInfo = new JLabel(); // initialise label vide
	private JLabel labelTotal = new JLabel(); // initialise label vide
	
	private GridBagConstraints contrainteCarte; // initialise GridBagConstraints vide
	private GridBagConstraints contrainteCategorie; // initialise GridBagConstraints vide
	private GridBagConstraints contrainteItem; // initialise GridBagConstraints vide
	
	
	
	public BDDrequetes bdd = new BDDrequetes(); // on initialise la connection à la base de donnée
	
	private BigDecimal total = BigDecimal.ZERO; // BigDecimal est un objet




	public commande() {
		
		bdd.connectionBDD(); // on lance la connection
		bdd.requeteCarte(); // on lance une requête pour récupérer les cartes
		
		
		this.setSize(1200, 600); // taille de la fenetre par défaut 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // action lors de la fermeture du programme
		
		
		// Panel mère horizontal -----------------------
		
		JPanel panelMere = new JPanel(new GridBagLayout()); // on crée un panel mère
		panelMere.setBorder(BorderFactory.createEmptyBorder(10,10,10,10)); // créer une bordure autour du panel mère
		
		GridBagConstraints contrainteMere = new GridBagConstraints(); // on pose une contrainte d'agencement
		contrainteMere.gridy = 0;
		contrainteMere.weighty = 1;
		contrainteMere.fill = GridBagConstraints.BOTH;
		contrainteMere.insets = new Insets(0, 5, 0, 5);
		
		// Panel Carte ---------------------------------
		
		panelCarte = new JPanel(new GridBagLayout());
		
		contrainteCarte = new GridBagConstraints();
		contrainteCarte.gridx = 0;
		contrainteCarte.fill = GridBagConstraints.HORIZONTAL;
		contrainteCarte.weightx = 1;
		
		rafraichirCarte(); // on rafraichit les cartes
		
		JScrollPane scrollPanelCarte = new JScrollPane(panelCarte); // crée un panneau scrollable
		scrollPanelCarte.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); // scroll vertical activé
		scrollPanelCarte.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // scroll horizontal désactivé
		scrollPanelCarte.getVerticalScrollBar().setUnitIncrement(30); // vitesse du scroll
		
		contrainteMere.gridx = 0;
		contrainteMere.weightx = 0.1;
		panelMere.add(scrollPanelCarte, contrainteMere);
		
		
		
		// Panel Categorie ----------------------------
		
		panelCategorie = new JPanel(new GridBagLayout());
		
		contrainteCategorie = new GridBagConstraints();
		contrainteCategorie.gridx = 0;
		contrainteCategorie.fill = GridBagConstraints.HORIZONTAL;
		contrainteCategorie.weightx = 1;
		
		rafraichirCategorie(1); // on affiche les catégories de la 1ère colonne par défaut
		
		JScrollPane scrollPanelCategorie = new JScrollPane(panelCategorie); // crée un panneau scrollable
		scrollPanelCategorie.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER); // cache la barre de scroll
		scrollPanelCategorie.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // cache la barre de scroll
		scrollPanelCategorie.getVerticalScrollBar().setUnitIncrement(30); // vitesse du scroll
		
		contrainteMere.gridx = 1;
		contrainteMere.weightx = 0.1;
		panelMere.add(scrollPanelCategorie, contrainteMere);
		
		
		// Panel Milieu ---------------------------------
		
		panelPlat = new JPanel(new GridBagLayout());
		
		contrainteItem = new GridBagConstraints();
		contrainteItem.fill = GridBagConstraints.NONE;
		contrainteItem.weightx = 0;
		contrainteItem.weighty = 0;
		contrainteItem.anchor = GridBagConstraints.NORTHWEST;
		
		
		JScrollPane scrollPanelPlat = new JScrollPane(panelPlat); // crée un panneau scrollable
		scrollPanelPlat.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); // scroll vertical activé
		scrollPanelPlat.getVerticalScrollBar().setUnitIncrement(30); // vitesse du scroll
		scrollPanelPlat.getHorizontalScrollBar().setUnitIncrement(30); // vitesse du scroll

        contrainteMere.gridx = 2;
        contrainteMere.weightx = 0.5;
        panelMere.add(scrollPanelPlat, contrainteMere);
   
        
	        
        // Panel Mere Panier ---------------------------------
		
		 JPanel panelMerePanier = new JPanel(new GridBagLayout());
		 panelMerePanier.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		 GridBagConstraints cMerePanier = new GridBagConstraints();
		 cMerePanier.gridx = 0;
		 cMerePanier.weightx = 1.0;
		 cMerePanier.fill = GridBagConstraints.BOTH;
		 
		
		 
		 // Panel Mere Panier HAUT ---------------------------------
		
		 JPanel panelPanierHaut = new JPanel(new GridBagLayout());
		 panelPanierHaut.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
		
		 GridBagConstraints cPanierHaut = new GridBagConstraints();
		 cPanierHaut.insets = new Insets(5, 5, 5, 5);
		 cPanierHaut.anchor = GridBagConstraints.NORTHWEST;
		 cPanierHaut.fill = GridBagConstraints.HORIZONTAL;
		
		 // Panel Mere Panier HAUT -> panel fille Recap + Total ---------------------------------
		 JPanel panelRecap = new JPanel();
		 panelRecap.setLayout(new BoxLayout(panelRecap, BoxLayout.Y_AXIS));
		
		 JLabel labelRecap = new JLabel("<html><u>Récapitulatif</u></html>");
		 labelRecap.setFont(new Font("Arial", Font.BOLD, 26));
		
		 rafraichirTotal();
		
		 panelRecap.add(labelRecap);
		 panelRecap.add(Box.createVerticalStrut(8));
		 panelRecap.add(labelTotal);
		
		 cPanierHaut.gridx = 0;
		 cPanierHaut.gridy = 0;
		 cPanierHaut.weightx = 0.6;
		 panelPanierHaut.add(panelRecap, cPanierHaut);
		
		 
		 // Panel Mere Panier HAUT -> panel fille Infos ---------------------------------
		 JPanel panelInfos = new JPanel(new GridBagLayout());
		 GridBagConstraints cPanierInfos = new GridBagConstraints();
		 cPanierInfos.gridx = 0;
		 cPanierInfos.weightx = 1.0;
		 cPanierInfos.fill = GridBagConstraints.HORIZONTAL;
		 cPanierInfos.insets = new Insets(3, 0, 3, 0);
		
			 // Labels dynamiques date et heure
			 JLabel labelDate = new JLabel();
			 JLabel labelHeure = new JLabel();
			
			 saisieNbrClient = new JTextField(5); // field saisie
			 saisieNumTable = new JTextField(5); // field saisie
			
			 // Ligne 0 -> Date
			 cPanierInfos.gridy = 0;
			 panelInfos.add(labelDate, cPanierInfos);
			
			 // Ligne 1 -> Heure
			 cPanierInfos.gridy = 1;
			 panelInfos.add(labelHeure, cPanierInfos);
			 
			 SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			 SimpleDateFormat heureFormat = new SimpleDateFormat("HH:mm");
			
			 Timer timer = new Timer(1000, e -> { 
			     Date now = new Date();
			     labelDate.setText("Date : " + dateFormat.format(now));
			     labelHeure.setText("Heure : " + heureFormat.format(now));
			 });
			 timer.start();
			
			 	
			 // Ligne 2 -> Clients
			 JPanel panelClients = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
			 panelClients.add(new JLabel("Clients : "));
			 panelClients.add(saisieNbrClient);
			
			 cPanierInfos.gridy = 2;
			 panelInfos.add(panelClients, cPanierInfos);
			 
			
			 // Ligne 3 -> Table
			 JPanel panelTable = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
			 panelTable.add(new JLabel("N° Table : "));
			 panelTable.add(saisieNumTable);
			
			 cPanierInfos.gridy = 3;
			 panelInfos.add(panelTable, cPanierInfos);
			 
			
			 // Ajout infos à droite
			 cPanierHaut.gridx = 1;
			 cPanierHaut.gridy = 0;
			 cPanierHaut.weightx = 0.4;
			 panelPanierHaut.add(panelInfos, cPanierHaut);
			 
			
			 // Ajout panel haut dans panelDroite
			 cMerePanier.gridy = 0;
			 cMerePanier.weighty = 0.0;
			 cMerePanier.anchor = GridBagConstraints.NORTH;
			 panelMerePanier.add(panelPanierHaut, cMerePanier);
		
		 
		 // Panel Mere Panier MILIEU + BAS -> panel panier + bouton valider  ---------------------------------
		 
		 JPanel panelMerePanierMilieuBas = new JPanel(new GridBagLayout());
		 GridBagConstraints cPanierWrapper = new GridBagConstraints();
		 cPanierWrapper.gridx = 0;
		 cPanierWrapper.gridy = 0;
		 cPanierWrapper.weightx = 1.0;
		 cPanierWrapper.weighty = 1;
		 cPanierWrapper.fill = GridBagConstraints.BOTH;
		
		 
		 panelPanier = new JPanel();
		 panelPanier.setLayout(new BoxLayout(panelPanier, BoxLayout.Y_AXIS));
		
		 JScrollPane scrollPanier = new JScrollPane(panelPanier);
		 scrollPanier.getVerticalScrollBar().setUnitIncrement(30);
		 scrollPanier.getHorizontalScrollBar().setUnitIncrement(30);

		 panelMerePanierMilieuBas.add(scrollPanier, cPanierWrapper);
		 
		 
		 // Bouton valider -----------------
		 JButton boutonValider = new JButton("Valider");
		 boutonValider.setBackground(Color.GREEN);
		 boutonValider.addActionListener(new clickActionValider());
		
		 cPanierWrapper.gridy = 1;
		 cPanierWrapper.weighty = 0;
		 cPanierWrapper.anchor = GridBagConstraints.SOUTH;
		 cPanierWrapper.insets = new Insets(5, 0, 0, 0);
		
		 panelMerePanierMilieuBas.add(boutonValider, cPanierWrapper);
		
		 // Ajout du wrapper dans panelMerePanier
		 cMerePanier.gridy = 1;
		 cMerePanier.weighty = 1.0;
		 panelMerePanier.add(panelMerePanierMilieuBas, cMerePanier);
		
		
		 
		 contrainteMere.gridx = 3;
		 contrainteMere.weightx = 0.05;
		 panelMere.add(panelMerePanier, contrainteMere);
		
		
		 rafraichirTotal();
		
		
		 // Ajouter panel mère à la fenêtre
		 this.add(panelMere);
		 this.setVisible(true);
		
	}


	
	public BigDecimal getTotal() {
		/**
		 * Récupérer le Total
		 */
		return total;
	}
	
	private void rafraichirTotal() {
		/**
		 * Rafraichir le total
		 */
    	labelTotal.removeAll();
    	
    	labelTotal.setText(String.format("Total : %.2f €", total));
        labelTotal.setFont(new Font("Arial", Font.BOLD, 18));
    }
	
	
	private void rafraichirCarte() {
		/*
		 * Récupérer et afficher toutes les cartes
		 */
		
		panelCarte.removeAll(); // on retire l'affichage précédent
		int i = 0;
    	for (List<String> carte : bdd.getElementsCarte()) {
	    	JButton bouton = new JButton("<html>" + carte.get(1) + "</html>"); // on initialise un nouveau bouton avec son nom affiché dessus
	        bouton.setName(carte.get(0)); // on pose le nom pour le désigner en interne
	        bouton.addActionListener(new clickActionCarte()); // signal des clicks sur le bouton            
	 
	            
	        bouton.setPreferredSize(new Dimension(0,50)); // largeur dynamique, hauteur fixe du bouton
	        contrainteCarte.gridy = i; // bouton sur chaque ligne
	        contrainteCarte.gridx = 0;
	        contrainteCarte.insets = new Insets(0, 0, 5, 0); // petit espacement en bas du bouton
	        panelCarte.add(bouton, contrainteCarte); // ajoute le bouton au panneau avec une contrainte
	        
	        
	        JButton boutonInfo = new JButton("<html>i</html>");
	        boutonInfo.setName(carte.get(0));
	        boutonInfo.addActionListener(new clickActionInfoCarte());
	        boutonInfo.setBackground(Color.YELLOW);
	        boutonInfo.setPreferredSize(new Dimension(0,50)); // largeur dynamique, hauteur fixe du bouton
	        contrainteCarte.gridx = 1;
	        contrainteCarte.gridy = i; // bouton sur chaque ligne
	        
	        contrainteCarte.weightx = 0.2 ;
	        contrainteCarte.insets = new Insets(0, 0, 5, 0); // petit espacement en bas du bouton
	        panelCarte.add(boutonInfo, contrainteCarte); // ajoute le bouton au panneau avec une contrainte
	        i++;
		}
	    	
	    // Composant invisible qui pousse tout vers le haut ----------
        GridBagConstraints contrainteFiller = new GridBagConstraints();
        contrainteFiller.gridx = 0;
        contrainteFiller.gridy = i;
        contrainteFiller.weighty = 1.0; // prend tout l'espace restant
        contrainteFiller.fill = GridBagConstraints.VERTICAL; // étire verticalement
        panelCarte.add(Box.createVerticalGlue(), contrainteFiller);
	    	
	    // Mise à jour de l'affichage
        panelCarte.revalidate();
        panelCarte.repaint();
    }
	
	private void rafraichirCategorie(int carte) {
		/**
		 * On affiche toutes les catégories de la carte sélectionnée
		 */
		
		panelCategorie.removeAll(); // on retire l'affichage précédent
	
		bdd.requeteCategorie(carte);
		int i = 0;

		for (List<String> categorie : bdd.getElementsCategorie()) {
	        JButton bouton = new JButton("<html>" + categorie.get(1) + "</html>"); // on initialise un nouveau bouton avec son nom affiché dessus
	        bouton.setName(categorie.get(0)); // on pose le nom pour le désigner en interne
	        bouton.addActionListener(new clickActionCategorie()); // signal des clicks sur le bouton
	
	        
	        bouton.setPreferredSize(new Dimension(0,50)); // largeur dynamique, hauteur fixe du bouton
	        contrainteCategorie.gridy = i; // bouton sur chaque ligne
	        contrainteCategorie.gridx = 0;
	        contrainteCategorie.weightx = 0.8 ;
	        contrainteCategorie.insets = new Insets(0, 0, 5, 0); // petit espacement en bas du bouton
	        panelCategorie.add(bouton, contrainteCategorie); // ajoute le bouton au panneau avec une contrainte
	        
	        JButton boutonInfo = new JButton("<html>i</html>");
	        boutonInfo.setName(categorie.get(0));
	        boutonInfo.setBackground(Color.YELLOW);
	        boutonInfo.addActionListener(new clickActionInfoCategorie());
	        boutonInfo.setPreferredSize(new Dimension(0,50)); // largeur dynamique, hauteur fixe du bouton
	        contrainteCategorie.gridx = 1;
	        contrainteCategorie.gridy = i; // bouton sur chaque ligne
	        contrainteCategorie.weightx = 0.2 ;
	        contrainteCategorie.insets = new Insets(0, 0, 5, 0); // petit espacement en bas du bouton
	        panelCategorie.add(boutonInfo, contrainteCategorie); // ajoute le bouton au panneau avec une contrainte
	        i++;
		}
    	
		// Composant invisible qui pousse tout vers le haut ----------
	    GridBagConstraints contrainteFiller = new GridBagConstraints();
	    contrainteFiller.gridx = 0;
	    contrainteFiller.gridy = i;
	    contrainteFiller.weighty = 1.0; // prend tout l'espace restant
	    contrainteFiller.fill = GridBagConstraints.VERTICAL; // étire verticalement
	    panelCategorie.add(Box.createVerticalGlue(), contrainteFiller);
	
	    
		// Mise à jour de l'affichage
	    panelCategorie.revalidate();
	    panelCategorie.repaint();

	}
	
	private void rafraichirItem(int categorie) {
		/**
		 * Récupère et affiche tout les items de la categorie sélectionnée
		 */
		
	    panelPlat.removeAll(); // on retire l'affichage précédent
	    bdd.requeteItem(categorie);
	    	
	    int colonnes = 3; // boutons par ligne
		int i = 0;
		
		for (List<String> item : bdd.getElementsItem()) {
			
			// on crée des petits panel pour chaque items afin de fusionner le bouton de l'item et le bouton de l'information de l'item
			JPanel panelFusionBouton = new JPanel(new GridBagLayout());
			GridBagConstraints cFusionBouton = new GridBagConstraints();

			
			JButton bouton = new JButton("<html>" + item.get(1) + "<br>" + item.get(2) + "€" + "</html>");
            bouton.setName(item.get(0));
            bouton.addActionListener(new clickActionItem());
            
            cFusionBouton.gridx = 0;
            cFusionBouton.gridy = 0;
            cFusionBouton.weightx = 0.9;
            cFusionBouton.weighty = 0.9;
            cFusionBouton.fill = GridBagConstraints.BOTH;
            panelFusionBouton.add(bouton, cFusionBouton);
            
            
            JButton boutonInfo = new JButton("<html>i</html>");
            boutonInfo.setName(item.get(0));
	        boutonInfo.setBackground(Color.YELLOW);
            boutonInfo.addActionListener(new clickActionInfoItem());
            
            cFusionBouton.gridx = 1;
            cFusionBouton.gridy = 0;
            cFusionBouton.weightx = 0.1;
            cFusionBouton.weighty = 0.1;
            cFusionBouton.fill = GridBagConstraints.BOTH;
            panelFusionBouton.add(boutonInfo, cFusionBouton);
            
            contrainteItem.gridx = i % colonnes; // colonne
            contrainteItem.gridy = i / colonnes; // ligne
            contrainteItem.insets = new Insets(0, 0, 5, 5);
            contrainteItem.fill = GridBagConstraints.BOTH;
            panelPlat.add(panelFusionBouton, contrainteItem);
            i++;
		}
		
		// Composant invisible qui pousse tout vers le haut ----------
        GridBagConstraints contrainteFiller = new GridBagConstraints();
        contrainteFiller.gridx = 0;
        contrainteFiller.gridy = (i / colonnes) + 1;
        contrainteFiller.weighty = 1; // prend tout l'espace restant
        contrainteFiller.fill = GridBagConstraints.VERTICAL; // étire verticalement
        panelPlat.add(Box.createVerticalGlue(), contrainteFiller);
    
		// Mise à jour de l'affichage
        panelPlat.revalidate();
        panelPlat.repaint();
    
    }
    
	
    private void rafraichirPanier() {
    	/**
    	 * Rafraichie le panier et le total pour chaque item ajouté ou supprimé
    	 */
    	
	    panelPanier.removeAll(); // on retire l'affichage précédent
	    total = BigDecimal.ZERO;
	    	
	    for (int idItem : this.panier.getPanier().keySet()) { // on récupère le set de clé de panier
	    	int quantite = this.panier.nbrItem(idItem); // on récupère les valeurs associées : quantité
	    		
    		// prix : on récup prixUnit str->BigDecimal puis on le multiplie par la quantité int->BigDecimal
    		BigDecimal prix = (new BigDecimal(bdd.getItems().get(idItem).get(1))).multiply(BigDecimal.valueOf(quantite));
			total = total.add(prix);
			
			JPanel panelLigne = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0)); // on crée un panel par ligne
			panelLigne.setAlignmentX(Component.LEFT_ALIGNMENT);
			panelLigne.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));

			JLabel ligneKey = new JLabel(" - " + bdd.getItems().get(idItem).get(0) + " : " + prix + "€"); // affichage clé : valeur
			ligneKey.setFont(new Font("Arial", Font.PLAIN, 14));
			ligneKey.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
			
			JLabel ligneValue = new JLabel(" " + quantite + " "); // affichage clé : valeur
			ligneValue.setFont(new Font("Arial", Font.PLAIN, 14));
			
			JButton boutonMoins1Item = new JButton("-");
			boutonMoins1Item.setPreferredSize(new Dimension(45, 25));
			boutonMoins1Item.setName(Integer.toString(idItem)); // on pose le nom pour le désigner en interne
			boutonMoins1Item.addActionListener(new clickActionMoins1Item());
		
			JButton boutonPlus1Item = new JButton("+");
			boutonPlus1Item.setPreferredSize(new Dimension(45, 25));
			boutonPlus1Item.setName(Integer.toString(idItem)); // on pose le nom pour le désigner en interne
			boutonPlus1Item.addActionListener(new clickActionPlus1Item());
			
			
			panelLigne.add(ligneKey);
			panelLigne.add(boutonMoins1Item);
			panelLigne.add(ligneValue);
			panelLigne.add(boutonPlus1Item);
			
			panelLigne.setMaximumSize(new Dimension(Integer.MAX_VALUE, panelLigne.getPreferredSize().height));
		
		    panelPanier.add(panelLigne); // on ajoute la ligne au panneau
		    
		}
	    
    	rafraichirTotal();
    	
		// Mise à jour de l'affichage
		panelPanier.revalidate();
		panelPanier.repaint();
    }
    
    

    
    
    
    public static void main(String[] args) {
        new commande();
    }
    
    
    
    
    // Action après un click de bouton
    
    class clickActionCarte implements ActionListener{
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks

			rafraichirCategorie(Integer.parseInt(bouton.getName()));
	    }
    }
    
    
    class clickActionCategorie implements ActionListener{
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks

			rafraichirItem(Integer.parseInt(bouton.getName()));
	    }
    }
    
    
    class clickActionItem implements ActionListener{
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks
	        panier.ajouterItem(Integer.parseInt(bouton.getName()), 1);
	        rafraichirPanier();
	    }
    }
    
    class clickActionMoins1Item implements ActionListener{
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks
	        panier.supprimerItem(Integer.parseInt(bouton.getName()));
	        rafraichirPanier();
	    }
    }
    
    class clickActionPlus1Item implements ActionListener{
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks
	        panier.ajouterItem(Integer.parseInt(bouton.getName()), 1);
	        rafraichirPanier();
	    }
    }
    
    
    class clickActionValider implements ActionListener{
		public void actionPerformed(ActionEvent Event) {
			if (panier.taillePanier() == 0) { // si le panier est vide
				titreInfo.setText("<html>" + "ERREUR" + "</html>");
				descriptionInfo.setText("<html>" + "Le panier est vide !" + "</html>");
				popupInfo();
				
			}else {
				String nbrClientsText = saisieNbrClient.getText();
				String numTableText = saisieNumTable.getText();
				int numTable = 0;
				int nbrClients = 0;
					
				try { // erreur lorsque les champs ne sont pas des nombres
					numTable = Integer.parseInt(numTableText);
					nbrClients = Integer.parseInt(nbrClientsText);					
				} catch (NumberFormatException e) {
					titreInfo.setText("<html>" + "ERREUR" + "</html>");
					descriptionInfo.setText("<html>" + "Les champs doivent contenir que des nombres !" + "</html>");
					popupInfo();
					throw e; // arrête la fonction
				}
								
				bdd.envoyerCommande(nbrClients, numTable, LocalDate.now(), LocalTime.now(), total, panier.getPanier());
				
				String ticketText = TicketPrinter.generateTicketCuisineText(
		                bdd,
		                nbrClients,
		                numTable,
		                total,
		                panier.getPanier()
		            );

		            TicketPrinter.printTicket(ticketText);

				dispose(); // ferme la fenêtre
			}
	    }
    }
    
    // click sur les boutons informations 
    
    class clickActionInfoCarte implements ActionListener{ 
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks
			
    		for (List<String> carte : bdd.getElementsCarte()) {
    			if (carte.get(0) == bouton.getName()) {
    				titreInfo.setText("<html>" + carte.get(1) + "</html>");
    				descriptionInfo.setText("<html>" + carte.get(2) + "</html>");
    				popupInfo();
    			}
    		}
	    }
    }
    
    class clickActionInfoCategorie implements ActionListener{ 
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks
			
	    		for (List<String> carte : bdd.getElementsCategorie()) {
	    			if (carte.get(0) == bouton.getName()) {
	    				titreInfo.setText("<html>" + carte.get(1) + "</html>");
	    				descriptionInfo.setText("<html>" + carte.get(2) + "</html>");
	    				popupInfo();
	    			}
	    		}		
	    }
    }
    
    class clickActionInfoItem implements ActionListener{ 
		public void actionPerformed(ActionEvent Event) {
			JButton bouton = (JButton) Event.getSource(); // on récupère la source des clicks
			
	    		for (List<String> carte : bdd.getElementsItem()) {
	    			if (carte.get(0) == bouton.getName()) {
	    				titreInfo.setText("<html>" + carte.get(1) + " : " + carte.get(2) + "€" + "</html>");
	    				descriptionInfo.setText("<html>" + carte.get(3) + "</html>");
	    				popupInfo();
	    			}
	    		}
	    }
    }
    
    
    // Les pop-up d'information
    
    public void popupInfo() {
    	// Créer un fond gris en arrière-plan et semi-transparent
        JPanel panelFondGris = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(0, 0, 0, 150)); // noir semi-transparent
                g.fillRect(0, 0, getWidth(), getHeight()); // dessine un rectangle sur toute la surface du panel
            }
        };
        panelFondGris.setOpaque(false); // pas opaque donc transparent
        panelFondGris.setLayout(new GridBagLayout()); // pour centrer le popup
        setGlassPane(panelFondGris); // effet popup : fond assombri et click intercepté
        
        // Contenu du popup -> custom
		
        JPanel popupPanel = new JPanel();
        popupPanel.setBackground(Color.WHITE); // fond blanc
        
        popupPanel.setLayout(new GridBagLayout());
        GridBagConstraints cPopup = new GridBagConstraints();
        cPopup.insets = new Insets(10, 10, 10, 10); // marge interne
        
        
        // bouton fermet popup -----------------------------
        JButton closeButton = new JButton("X");
        closeButton.setBackground(Color.RED);
        closeButton.setFocusPainted(false); // supprime le contour/bordure du focus
        cPopup.gridx = 1;
        cPopup.gridy = 0;
        cPopup.weightx = 0;
        cPopup.weighty = 0;
        cPopup.anchor = GridBagConstraints.NORTHEAST;
        cPopup.fill = GridBagConstraints.NONE;
        
        popupPanel.add(closeButton, cPopup);
        
        
        // titre --------------------------
        titreInfo.setHorizontalAlignment(SwingConstants.CENTER);
        cPopup.gridx = 0;
        cPopup.gridy = 0;
        cPopup.weightx = 0;
        cPopup.weighty = 0;
        cPopup.fill = GridBagConstraints.BOTH;
        cPopup.anchor = GridBagConstraints.NORTH;

        popupPanel.add(titreInfo, cPopup);
        
        
        // description ----------------------
        descriptionInfo.setHorizontalAlignment(SwingConstants.CENTER);

        cPopup.gridx = 0;
        cPopup.gridy = 1;
        cPopup.gridwidth = 1;
        cPopup.weightx = 1;
        cPopup.weighty = 1;
        cPopup.fill = GridBagConstraints.BOTH;
        cPopup.anchor = GridBagConstraints.CENTER;

        popupPanel.add(descriptionInfo, cPopup);
        
        
        // Ajouter le popup au glassPane
        panelFondGris.add(popupPanel);

        // Action pour afficher le popup
        panelFondGris.setVisible(true);

        // Action pour fermer le popup
        closeButton.addActionListener((ActionEvent e) -> {
        	panelFondGris.setVisible(false);
        });
    }
}
